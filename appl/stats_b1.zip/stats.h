/**************************************************************************************************/
/** @file     stats.h
 *  @brief    Statistics Interface File
 *  @details  x
 *
 *	@section  	Notes
 *		Interface file headers like this are not recommended in preference for the source header
 */
/**************************************************************************************************/
#ifndef CORE_APP_STATS_H_
#define CORE_APP_STATS_H_

//FreeRTOS Includes
#include "freertos/FreeRTOS.h"						/* ? 										  */


//Global Routines
extern esp_err_t print_real_time_stats(TickType_t xTicksToWait);	/* and section divs (e.g. 
																	  'DECLARATIONS' here) are also 
																	  not rec for lightweight 
																	  interface files like this 
																	  either - 'KISS'  			  */
#endif /* CORE_APP_STATS_H_ */
